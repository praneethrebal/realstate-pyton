from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import *

ROLE_CHOICES = [
  
    ('PROFESSIONAL', 'Professional'),
    ('OWNER', 'Citizen'),
    ('MARKETER', 'Marketer'),
]

PLAN_CHOICES = [
    ('MARKETER_EXPORT', 'Exports (₹7999)'),
    ('MARKETER_EXPORT_PRO', 'Exports Pro (₹14999)'),
]

CATEGORY_CHOICES = [
    ('Plumber', 'Plumber'),
    ('Painter', 'Painter'),
    ('Electrician', 'Electrician'),
    ('Constructor', 'Constructor'),
    ('Centring', 'Centring'),
    ('Interior designer', 'Interior designer'),
    ('Architecture', 'Architecture'),
    ('Civil engineer', 'Civil engineer'),
    ('Tiles works', 'Tiles works'),
    ('Marble works', 'Marble works'),
    ('Grinate works', 'Grinate works'),
    ('Wood works', 'Wood works'),
    ('Glass works', 'Glass works'),
    ('Steel railing works', 'Steel railing works'),
    ('Carpenter', 'Carpenter'),
    ('Doozer works', 'Doozer works'),
    ('JCB works', 'JCB works'),
    ('Borewells', 'Borewells'),
    ('Material supplier', 'Material supplier'),
]

class UserRegisterForm(UserCreationForm):
    role = forms.ChoiceField(choices=ROLE_CHOICES)
    category = forms.ChoiceField(choices=CATEGORY_CHOICES, required=False)
    plan_type = forms.ChoiceField(choices=PLAN_CHOICES, required=False, widget=forms.RadioSelect(attrs={'class': 'plan-radio-select'}))
    description = forms.CharField(widget=forms.Textarea(attrs={'placeholder': 'Description'}), required=False)
    location = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Location'}), required=False)
    experience = forms.IntegerField(required=False)
    deals = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Deals (Optional)'}), required=False)
    profile_image_path = forms.ImageField(required=False, widget=forms.FileInput(attrs={'id': 'id_profile_image_path'}))

    class Meta(UserCreationForm.Meta):
        model = User
        fields = (
            'username', 'email', 'phone', 
            'role', 'category', 'plan_type', 'description', 'location',
            'experience', 'referred_by_code', 'deals', 'profile_image_path'
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        placeholders = {
            'username': 'Full Name',
            'email': 'Email',
            'phone': 'Phone Number',
            'password1': 'Password',
            'password2': 'Confirm Password',
        }
        for field_name, placeholder_text in placeholders.items():
            self.fields[field_name].widget.attrs['placeholder'] = placeholder_text
            self.fields[field_name].help_text = '' # Remove default help text
        
        # Make profile image label invisible as it's handled by the template
        self.fields['profile_image_path'].label = ""


from .models import MoveRequest

class MoveRequestForm(forms.ModelForm):
    class Meta:
        model = MoveRequest
        fields = [
            "customer_name", "number", "alternate_number", "service_type",
            "from_location", "to_location", "from_floor", "to_floor",
            "men_power", "vehicle_type", "additional_info"
        ]





from django import forms
from .models import HouseVilla

class HouseVillaForm(forms.ModelForm):
    class Meta:
        model = HouseVilla
        fields = '__all__'
        widgets = {
            'project_name': forms.TextInput(attrs={'placeholder': 'Enter project name'}),
            'extent': forms.TextInput(attrs={'placeholder': 'e.g. 300 sqyd'}),
            'facing': forms.TextInput(attrs={'placeholder': 'e.g. East, North'}),
            'no_of_bhk': forms.NumberInput(attrs={'placeholder': 'e.g. 3'}),
            'no_of_floors': forms.NumberInput(attrs={'placeholder': 'e.g. 2'}),
            'road_size': forms.TextInput(attrs={'placeholder': 'e.g. 33 feet'}),
            'built_up_area': forms.TextInput(attrs={'placeholder': 'e.g. 2400 sqft'}),
            'open_area': forms.TextInput(attrs={'placeholder': 'e.g. Garden'}),
            'rental_income': forms.TextInput(attrs={'placeholder': 'e.g. ₹50,000'}),
            'dimensions': forms.TextInput(attrs={'placeholder': 'e.g. 36x50'}),
        }




from django import forms
from .models import DisputeLand

class DisputeLandForm(forms.ModelForm):
    class Meta:
        model = DisputeLand
        fields = '__all__'


from .models import PropertyDemand

class PropertyDemandForm(forms.ModelForm):
    class Meta:
        model = PropertyDemand
        fields = '__all__'



class FarmPlotForm(forms.ModelForm):
    class Meta:
        model = FarmPlotProperty
        fields = ['project_name', 'extent', 'units', 'facing', 'dimensions']
        widgets = {
            'project_name': forms.TextInput(attrs={'placeholder': 'e.g., Green Valley'}),
            'extent': forms.TextInput(attrs={'placeholder': 'e.g., 1200'}),
            'units': forms.Select(),
            'facing': forms.TextInput(attrs={'placeholder': 'e.g., East'}),
            'dimensions': forms.TextInput(attrs={'placeholder': 'e.g., 36x50'}),
        }



        from django import forms
from .models import PropertyDemand

class PropertyDemand(forms.ModelForm):
    class Meta:
        model = PropertyDemand
        fields = ['rera_approved', 'approval_type', 'amenities', 'highlights']
        widgets = {
            'amenities': forms.HiddenInput(),
            'highlights': forms.Textarea(attrs={'rows':3, 'maxlength':50, 'placeholder':'Write highlights here...'})
        }
