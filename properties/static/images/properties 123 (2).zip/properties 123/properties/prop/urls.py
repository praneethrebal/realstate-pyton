from django.urls import path
from . import views

urlpatterns = [
       
    path('', views.home_view, name='home'),
    path('move/', views.move_page, name='move_page'),
    path('build/', views.build_page, name='build_page'),
    path('loan/', views.loan_page, name='loan_page'),
    path("login/register", views.register_user, name="register"),
    path("login/", views.login_user, name="login"),
     path('dashboard/', views.dashboard, name='dashboard'),
     path("contact/",views.contact_page,name="contact"),
     path("build/",views.build_contact,name="build_contact"),
     path("emi/",views.emi_page,name="emi_page"),
     path('house/',views.housevilla_form, name='house_villa'),
    path('house-villa/', views.house_villa_list, name='house_villa_list'),
    path('house-villa/edit/<int:id>/', views.house_villa_edit, name='house_villa_edit'),
    path('house-villa/delete/<int:id>/', views.house_villa_delete, name='house_villa_delete'),
    path('plot/', views.plot_form_view, name='plot_form'),
    path('plot-success/', views.plot_success, name='plot_success'),
    path('flats/', views.flats_form_view, name='flats_form'),
    path('flat-success', views.flats_success_view, name='flat_success'),
    path('villa/', views.villa_form_view, name='villa_form'),
    path('villa-success/', views.villa_success_view, name='villa_success'),
     path('land/', views.land_form_view, name='land_form'),
     path('land-success/', views.land_success_view, name='land_success'),
     path('disputeland/',views.disputeland, name="disputeland"),
      path('property-demand/', views.property_demand_view, name='property_demand'),
 path('final/upload/', views.final_upload, name='final_upload'),
    path('final/list/', views.final_upload_list, name='final_upload_list'),
                      path('success/', views.success_page, name='success_page'),  # ✅ Add this line
         path('common-land/', views.common_land_view, name='common_land'),
         path('farmplot/', views.farmplot, name="farmplot"),
             path('properties/', views.combined_properties, name='combined_properties'),


]
