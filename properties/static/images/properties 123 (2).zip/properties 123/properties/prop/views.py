from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from .forms import *


# ------------------------
# PUBLIC PAGES
# ------------------------
def home_view(request):
    return render(request, 'home.html')

def move_page(request):
    return render(request, 'move.html')

def build_page(request):
    return render(request, 'build.html')

def loan_page(request):
    return render(request, 'loan.html')


# ------------------------
# REGISTER USER
# ------------------------
def register_user(request):
    if request.method == "POST":
        form = UserRegisterForm(request.POST, request.FILES)
        if form.is_valid():
            role = form.cleaned_data.get('role')
            user_instance = form.save(commit=False)

            if role == 'PROFESSIONAL':
                user_instance.plan_type = 'PROFESSIONAL_SINGLE'

            user_instance.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"Account created for {username}! You can now log in.")
            return redirect("login") 
    else:
        form = UserRegisterForm()
    return render(request, "register.html", {"form": form})


# ------------------------
# LOGIN / LOGOUT
# ------------------------
def login_user(request):
    """Handles login using Django's AuthenticationForm"""
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome {username}!")
                return redirect("dashboard")  # ✅ Redirect to dashboard
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, "login.html", {"login_form": form})


@login_required(login_url='login')
def dashboard(request):
    """User dashboard after login"""
    return render(request, 'dashboard.html')


@login_required(login_url='login')
def user_logout(request):
    """Logs out the user"""
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('home')

def contact_page(request):
    return render (request,'contact.html')

def build_contact(request):
    return render(request,'build.html')


def loan_page(request):
    return render(request, 'loan.html')

def emi_page(request):
    return render(request,'emi.html')


from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import MoveRequestForm

def contact_view(request):
    if request.method == "POST":
        form = MoveRequestForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Your request has been submitted! Our team will contact you soon.")
            return redirect('contact')  # reload the same page or redirect elsewhere
    else:
        form = MoveRequestForm()
    return render(request, "contact.html", {"form": form})

from django.shortcuts import render


from django.shortcuts import render, redirect, get_object_or_404
from .models import HouseVilla, PropertyDemand


# ✅ CREATE new House/Villa record
def housevilla_form(request):
    if request.method == "POST":
        project_name = request.POST.get('project_name')
        extent = request.POST.get('extent')
        units = request.POST.get('units')
        facing = request.POST.get('facing')
        no_of_bhk = request.POST.get('no_of_bhk')
        no_of_floors = request.POST.get('no_of_floors')
        road_size = request.POST.get('road_size')
        built_up_area = request.POST.get('built_up_area')
        open_area = request.POST.get('open_area') or None
        rental_income = request.POST.get('rental_income') or None
        dimensions = request.POST.get('dimensions')

        # Save to database
        HouseVilla.objects.create(
            project_name=project_name,
            extent=extent,
            units=units,
            facing=facing,
            no_of_bhk=no_of_bhk,
            no_of_floors=no_of_floors,
            road_size=road_size,
            built_up_area=built_up_area,
            open_area=open_area,
            rental_income=rental_income,
            dimensions=dimensions,
        )

        return redirect('')  # Redirect to list after saving

    return render(request, 'house_villa_form.html')


# ✅ READ / LIST all House/Villa records
def house_villa_list(request):
    villas = HouseVilla.objects.all().order_by('-id')  # newest first
    return render(request, 'singlepropertys/house_villa_list.html', {'villas': villas})


# ✅ UPDATE existing House/Villa record
def house_villa_edit(request, id):
    villa = get_object_or_404(HouseVilla, id=id)

    if request.method == "POST":
        villa.project_name = request.POST.get('project_name')
        villa.extent = request.POST.get('extent')
        villa.units = request.POST.get('units')
        villa.facing = request.POST.get('facing')
        villa.no_of_bhk = request.POST.get('no_of_bhk')
        villa.no_of_floors = request.POST.get('no_of_floors')
        villa.road_size = request.POST.get('road_size')
        villa.built_up_area = request.POST.get('built_up_area')
        villa.open_area = request.POST.get('open_area')
        villa.rental_income = request.POST.get('rental_income')
        villa.dimensions = request.POST.get('dimensions')
        villa.save()
        return redirect('house_villa_list')

    return render(request, 'house_villa_edit.html', {'villa': villa})


# ✅ DELETE a House/Villa record
def house_villa_delete(request, id):
    villa = get_object_or_404(HouseVilla, id=id)
    villa.delete()
    return redirect('house_villa_list')

from django.shortcuts import render, redirect
from .models import PropertyDemand, FinalUpload

# -----------------------
# Property Demand View
# -----------------------
def property_demand_view(request):
    if request.method == "POST":
        land_type = request.POST.get('land_type')
        extent = request.POST.get('extent')
        units = request.POST.get('units')
        soil_type = request.POST.get('soil_type')
        zone = request.POST.get('zone')
        road_size = request.POST.get('road_size')
        road_facing_size = request.POST.get('road_facing_size')
        development_type = request.POST.get('development_type')
        expecting_advance = request.POST.get('expecting_advance')
        ratio = request.POST.get('ratio')

        # Save Property Demand record
        PropertyDemand.objects.create(
            land_type=land_type,
            extent=extent,
            units=units,
            soil_type=soil_type,
            zone=zone,
            road_size=road_size,
            road_facing_size=road_facing_size,
            development_type=development_type,
            expecting_advance=expecting_advance,
            ratio=ratio,
        )

        # After saving, redirect to Final Upload form
        return redirect('final_upload')

    return render(request, 'property_demand.html')


# -----------------------
# Final Upload View
# -----------------------
from django.shortcuts import render, redirect
from .models import FinalUpload, FinalUploadPhoto
from django.shortcuts import render, redirect, get_object_or_404
from .models import FinalUpload, FinalUploadPhoto

# ✅ CREATE (Upload form)
def final_upload(request):
    if request.method == "POST":
        location = request.POST.get('location')
        location_url = request.POST.get('location_url')
        price = request.POST.get('price')
        main_photo = request.FILES.get('main_photo')
        videos = request.FILES.get('videos')
        documents = request.FILES.get('documents')
        photo_files = request.FILES.getlist('photos')

        final_upload = FinalUpload.objects.create(
            location=location,
            location_url=location_url,
            price=price,
            main_photo=main_photo,
            videos=videos,
            documents=documents
        )

        # Save multiple images (up to 10)
        for file in photo_files[:10]:
            FinalUploadPhoto.objects.create(final_upload=final_upload, image=file)

        return redirect('final_upload_list')

    return render(request, 'final_upload.html')


# ✅ READ (List all uploads)
def final_upload_list(request):
    uploads = FinalUpload.objects.all().order_by('-id')
    return render(request, 'singlepropertys/final_upload_list.html', {'uploads': uploads})

def combined_properties(request):
    villas = HouseVilla.objects.all()
    uploads = FinalUpload.objects.all()
    return render(request, "singlepropertys/combined_properties.html", {"villas": villas, "uploads": uploads})


# -----------------------
# Success Page View
# -----------------------
def success_page(request):
    return render(request, "success_page.html")


from django.shortcuts import render, redirect
from .models import PlotForm  # import your model at the top

def plot_form_view(request):
    if request.method == "POST":
        project_name = request.POST.get('project_name')
        extent = request.POST.get('extent')
        unit = request.POST.get('unit')
        facing = request.POST.get('facing')
        dimensions = request.POST.get('dimensions')
        road_size = request.POST.get('road_size')

        # Save to database
        PlotForm.objects.create(
            project_name=project_name,
            extent=extent,
            unit=unit,
            facing=facing,
            dimensions=dimensions,
            road_size=road_size
        )

        # Redirect to success page
        return redirect('property_demand')  # make sure this name matches urls.py

    # Render form if GET request
    return render(request, 'plot_form.html')


def plot_success(request):
    return render(request, 'plot_success.html')  # simple success page




from django.shortcuts import render, redirect
from .models import Flat

def flats_form_view(request):
    if request.method == "POST":
        project_name = request.POST.get('project_name')
        extent = request.POST.get('extent')
        unit = request.POST.get('unit')
        facing = request.POST.get('facing')
        bhk = request.POST.get('bhk')
        floor_no = request.POST.get('floor_no')
        community_type = request.POST.get('community_type')
        builtup_area = request.POST.get('builtup_area')
        carpet_area = request.POST.get('carpet_area')

        # Save data to DB
        Flat.objects.create(
            project_name=project_name,
            extent=extent,
            unit=unit,
            facing=facing,
            bhk=bhk,
            floor_no=floor_no,
            community_type=community_type,
            builtup_area=builtup_area,
            carpet_area=carpet_area
        )

        # Redirect to success page
        return redirect('property_demand')

    return render(request, 'flat_form.html')


def flats_success_view(request):
    return render(request, 'flat_success.html')



from django.shortcuts import render, redirect
from .models import Villa

def villa_form_view(request):
    if request.method == "POST":
        project_name = request.POST.get('project_name')
        extent = request.POST.get('extent')
        units = request.POST.get('units')
        facing = request.POST.get('facing')
        bhk = request.POST.get('bhk')
        floors = request.POST.get('floors')
        road_size = request.POST.get('road_size')
        built_up_area = request.POST.get('built_up_area')
        open_area = request.POST.get('open_area')
        rental_income = request.POST.get('rental_income')
        dimensions = request.POST.get('dimensions')

        # Save data to database
        Villa.objects.create(
            project_name=project_name,
            extent=extent,
            units=units,
            facing=facing,
            bhk=bhk,
            floors=floors,
            road_size=road_size,
            built_up_area=built_up_area,
            open_area=open_area,
            rental_income=rental_income,
            dimensions=dimensions
        )

        return redirect('property_demand')  # redirects after saving

    return render(request, 'villa_form.html')  # your HTML form


def villa_success_view(request):
    return render(request, 'villa_success.html')




from django.shortcuts import render, redirect
from .models import LandProperty

def land_form_view(request):
    if request.method == 'POST':
        type_of_land = request.POST.get('type_of_land')
        extent = request.POST.get('extent')
        units = request.POST.get('units')
        soil = request.POST.get('soil')
        water_source = request.POST.get('water_source')
        road_size = request.POST.get('road_size')
        road_facing = request.POST.get('road_facing')

        # Save data into database
        LandProperty.objects.create(
            type_of_land=type_of_land,
            extent=extent,
            units=units,
            soil=soil,
            water_source=water_source,
            road_size=road_size,
            road_facing=road_facing
        )

       
        return redirect('property_demand')

    return render(request, 'land.html')
    

def land_success_view(request):
    return render(request, 'land_success.html')


from .models import DisputeLand
from .forms import DisputeLandForm  # make sure you created this in forms.py

def disputeland(request):
    if request.method == "POST":
        form = DisputeLandForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, "disputeland.html", {"success": True})
    else:
        form = DisputeLandForm()
        
    return render(request, "disputeland.html", {"form": form})



from django.shortcuts import render, redirect
from .models import CommonLand
from django import forms

# Create a form for CommonLand
class CommonLandForm(forms.ModelForm):
    class Meta:
        model = CommonLand
        fields = [
            'land_type',
            'extent',
            'units',
            'soil_type',
            'water_source',
            'road_size',
            'road_facing',
        ]
        widgets = {
            'land_type': forms.Select(attrs={'class': 'form-control'}),
            'extent': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 5000'}),
            'units': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Sq.Yards'}),
            'soil_type': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Red soil'}),
            'water_source': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Borewell'}),
            'road_size': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 30ft'}),
            'road_facing': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. East'}),
        }

# View to handle form display and submission
def common_land_view(request):
    success = False
    if request.method == "POST":
        form = CommonLandForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('property_demand')  # Redirect after successful submission
    else:
        form = CommonLandForm()

    return render(request, 'common_land.html', {'form': form})


def farmplot(request):
    if request.method == "POST":
        form = FarmPlotForm(request.POST)
        if form.is_valid():
            form.save()
            # ✅ Corrected template name and syntax
            return redirect('property_demand')
    else:
        form = FarmPlotForm()
    
    return render(request, "flot_form.html", {"form": form})


def commonp(request):
    if request.method == "POST":
        rera_approved = request.POST.get('rera_approved')
        approval_type = request.POST.get('approval_type')
        amenities = request.POST.get('amenities')   
        highlights = request.POST.get('highlights')

        