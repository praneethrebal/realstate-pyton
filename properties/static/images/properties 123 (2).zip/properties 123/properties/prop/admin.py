

from django.contrib import admin
from .models import User

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'user_referral_code','username', 'email', 'phone', 'role', 'plan_type', 'click', 'leads')
    search_fields = ('username', 'email', 'phone', 'company_name')
    list_filter = ('role', 'plan_type', 'created_at')


from django.contrib import admin
from .models import MoveRequest,HouseVilla,PlotForm,Flat,Villa,DisputeLand

@admin.register(MoveRequest)
class MoveRequestAdmin(admin.ModelAdmin):
    list_display = ("customer_name", "number", "service_type", "from_location", "to_location", "created_at")
    search_fields = ("customer_name", "number", "service_type", "from_location", "to_location")
    list_filter = ("service_type", "created_at")



@admin.register(HouseVilla)
class HousevillaAdmin(admin.ModelAdmin):
    list_display = ('project_name','extent',
        'units',
        'facing',
        'no_of_bhk',
        'no_of_floors',
        'road_size',
        'built_up_area',
        'open_area',
        'rental_income',
        'dimensions')
    

@admin.register(PlotForm)
class plotformAdmin(admin.ModelAdmin):
  list_display = ('project_name', 'extent', 'unit', 'facing', 'dimensions', 'road_size')


@admin.register(Flat)
class FlatAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'extent', 'unit', 'facing', 'bhk', 'floor_no', 'community_type', 'builtup_area', 'carpet_area')
    



@admin.register(Villa)
class VillaAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'extent', 'units', 'bhk', 'floors', 'road_size', 'created_at')




from .models import LandProperty,PropertyDemand,FinalUpload

@admin.register(LandProperty)
class LandPropertyAdmin(admin.ModelAdmin):
    list_display = ('type_of_land', 'extent', 'units', 'soil', 'water_source', 'road_size', 'road_facing')


@admin.register(DisputeLand)
class DisputeLandAdmin(admin.ModelAdmin):
    list_display = (
        'land_type',
        'extent',
        'units',
        'soil_type',
        'zone',
        'road_size',
        'road_facing_size',
        'intention',
        'actual_price',
        'sale_price',
        'created_at',
    )



@admin.register(PropertyDemand)
class PropertyDemandAdmin(admin.ModelAdmin):
    list_display = (
        "land_type",
        "extent",
        "units",
        "soil_type",
        "zone",
        "road_size",
        "road_facing_size",
        "development_type",
        "expecting_advance",
        "ratio",
        "created_at",
    )




from django.contrib import admin
from .models import FinalUpload, FinalUploadPhoto,LandProperty,FarmPlotProperty

# Inline for multiple photos
class FinalUploadPhotoInline(admin.TabularInline):
    model = FinalUploadPhoto
    extra = 1

# Main FinalUpload Admin
@admin.register(FinalUpload)
class FinalUploadAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'location',
        'price',
        'location_url',
        'main_photo',
        'videos',
        'documents',
        'created_at',
    )
    inlines = [FinalUploadPhotoInline]

from .models import CommonLand

@admin.register(CommonLand)
class CommonLandAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'land_type',
        'extent',
        'units',
        'soil_type',
        'water_source',
        'road_size',
        'road_facing',
        'created_at',
    )



@admin.register(FarmPlotProperty)
class FarmPlotPropertyAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'extent', 'units', 'facing', 'dimensions', 'created_at')
    search_fields = ('project_name', 'facing')
    list_filter = ('units', 'facing')
    ordering = ('-created_at',)