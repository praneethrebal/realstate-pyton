from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
import random
import re

# ===== Enum Classes =====

class Role(models.TextChoices):
    OWNER = 'OWNER', 'Owner'
    MARKETER = 'MARKETER', 'Marketer'
    PROFESSIONAL = 'PROFESSIONAL', 'Professional'
    COMPANY = 'COMPANY', 'Company'
    FRANCHISE = 'FRANCHISE', 'Franchise'


class PlanType(models.TextChoices):
    MARKETER_EXPORT = 'MARKETER_EXPORT', 'Marketer Export'
    MARKETER_EXPORT_PRO = 'MARKETER_EXPORT_PRO', 'Marketer Export Pro'
    PROFESSIONAL_SINGLE = 'PROFESSIONAL_SINGLE', 'Professional Single'
    COMPANY_NORMAL = 'COMPANY_NORMAL', 'Company Normal'
    COMPANY_PRO = 'COMPANY_PRO', 'Company Pro'


class CompanySubscriptionType(models.TextChoices):
    NORMAL = 'NORMAL', 'Normal'
    PRO = 'PRO', 'Pro'


class MarketingSubscriptionType(models.TextChoices):
    EXPORT = 'EXPORT', 'Export'
    EXPORT_PRO = 'EXPORT_PRO', 'Export Pro'


# ===== User Model =====

class User(AbstractUser):
    # Unique fields
    phone = models.CharField(max_length=15, unique=True, null=True, blank=True)
    email = models.EmailField(unique=True)

    # Core profile fields
    category = models.CharField(max_length=100, null=True, blank=True)
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.PROFESSIONAL)
    plan_type = models.CharField(max_length=30, choices=PlanType.choices, null=True, blank=True)

    # Optional details
    description = models.TextField(null=True, blank=True)
    location = models.CharField(max_length=255, null=True, blank=True)
    experience = models.IntegerField(null=True, blank=True)
    user_referral_code = models.CharField(max_length=50, null=True, blank=True, unique=True, help_text="This user's own unique referral code.")
    referred_by_code = models.CharField(max_length=50, null=True, blank=True, help_text="The referral code used by the user during registration.")
    deals = models.CharField(max_length=255, null=True, blank=True)

    # ===== Image fields =====
    # profile_image_name = models.CharField(max_length=255, null=True, blank=True)
    profile_image_path = models.CharField(max_length=255, default='images/Default_profile_picture.jpeg')
    # profile_image_type = models.CharField(max_length=50, null=True, blank=True)

    # company_logo_name = models.CharField(max_length=255, null=True, blank=True)
    company_logo_path = models.CharField(max_length=255, null=True, blank=True)
    # company_logo_type = models.CharField(max_length=50, null=True, blank=True)

    # company_wallpaper_name = models.CharField(max_length=255, null=True, blank=True)
    company_wallpaper_path = models.CharField(max_length=255, null=True, blank=True)
    # company_wallpaper_type = models.CharField(max_length=50, null=True, blank=True)

    # ===== Company Details =====
    company_name = models.CharField(max_length=255, null=True, blank=True)
    address = models.CharField(max_length=255, null=True, blank=True)
    logo_url = models.CharField(max_length=255, null=True, blank=True)

    # ===== Metrics =====
    click = models.BigIntegerField(default=0)
    leads = models.BigIntegerField(default=0)

    total_projects = models.IntegerField(null=True, blank=True)
    ongoing_projects = models.IntegerField(null=True, blank=True)
    completed_projects = models.IntegerField(null=True, blank=True)

    # ===== Contact Info =====
    contact_number = models.CharField(max_length=15, null=True, blank=True)
    selected_duration = models.IntegerField(default=0)

    # ===== Dates =====
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    company_subscription_start_date = models.DateField(null=True, blank=True)
    company_subscription_end_date = models.DateField(null=True, blank=True)
    marketer_subscription_start_date = models.DateField(null=True, blank=True)
    marketer_subscription_end_date = models.DateField(null=True, blank=True)

    # ===== Subscription Types =====
    company_subscription_type = models.CharField(
        max_length=50,
        choices=CompanySubscriptionType.choices,
        null=True,
        blank=True
    )
    marketing_subscription_type = models.CharField(
        max_length=50,
        choices=MarketingSubscriptionType.choices,
        null=True,
        blank=True
    )

    # ===== Utility =====
    def __str__(self):
        return self.username or "Unnamed User"

    @property
    def plan_price(self):
        prices = {
            'MARKETER_EXPORT': 7999,
            'MARKETER_EXPORT_PRO': 14999,
            'PROFESSIONAL_SINGLE': 4999,
            'COMPANY_NORMAL': 14999,
            'COMPANY_PRO': 19999,
        }
        return prices.get(self.plan_type, 0)

    # ===== Referral Code Generation =====
    def _generate_referral_code(self):
        """Generates a unique referral code based on ID and role."""
        id_part = str(self.id)
        role_part = (self.role[:2].upper() if self.role else "XX")
        name_clean = re.sub(r'[^A-Za-z0-9]', '', self.username or '')
        name_part = name_clean[:3].upper() if name_clean else "USR"
        random_part = str(random.randint(1000, 9999))
        return f"{role_part}{id_part}{name_part}{random_part}"

    def save(self, *args, **kwargs):
        # Save the user instance first, especially to get an ID for new users.
        super().save(*args, **kwargs)
        # If it's a new user and they don't have a referral code yet, generate one.
        if not self.user_referral_code and self.pk:
            self.user_referral_code = self._generate_referral_code()
            # Update only the referral code field to avoid recursion
            User.objects.filter(pk=self.pk).update(user_referral_code=self.user_referral_code)





class MoveRequest(models.Model):
    customer_name = models.CharField(max_length=100)
    number = models.CharField(max_length=15)
    alternate_number = models.CharField(max_length=15, blank=True, null=True)
    service_type = models.CharField(max_length=50)
    from_location = models.CharField(max_length=100)
    to_location = models.CharField(max_length=100)
    from_floor = models.CharField(max_length=50, blank=True, null=True)
    to_floor = models.CharField(max_length=50, blank=True, null=True)
    men_power = models.CharField(max_length=50, blank=True, null=True)
    vehicle_type = models.CharField(max_length=50, blank=True, null=True)
    additional_info = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.customer_name



from django.db import models

class HouseVilla(models.Model):
    project_name = models.CharField(max_length=200)
    extent = models.CharField(max_length=100)
    units = models.CharField(max_length=50)
    facing = models.CharField(max_length=50)
    no_of_bhk = models.PositiveIntegerField()
    no_of_floors = models.PositiveIntegerField()
    road_size = models.CharField(max_length=50)
    built_up_area = models.CharField(max_length=100)
    open_area = models.CharField(max_length=100, blank=True, null=True)
    rental_income = models.CharField(max_length=50, blank=True, null=True)
    dimensions = models.CharField(max_length=50)

    def __str__(self):
        return self.project_name



from django.db import models

class PlotForm(models.Model):
    project_name = models.CharField(max_length=200)
    extent = models.CharField(max_length=100)
    unit = models.CharField(max_length=50)
    facing = models.CharField(max_length=50)
    dimensions = models.CharField(max_length=50)
    road_size = models.CharField(max_length=50)

    def __str__(self):
        return self.project_name




from django.db import models

class Flat(models.Model):
    project_name = models.CharField(max_length=200)
    extent = models.FloatField()
    unit = models.CharField(max_length=50)
    facing = models.CharField(max_length=50)
    bhk = models.IntegerField()
    floor_no = models.IntegerField()
    community_type = models.CharField(max_length=100)
    builtup_area = models.CharField(max_length=50)
    carpet_area = models.CharField(max_length=50)

    def __str__(self):
        return self.project_name





# models.py
from django.db import models

class Villa(models.Model):
    project_name = models.CharField(max_length=200)
    extent = models.CharField(max_length=100)
    units = models.CharField(max_length=50)
    facing = models.CharField(max_length=100, blank=True, null=True)
    bhk = models.CharField(max_length=50, blank=True, null=True)
    floors = models.CharField(max_length=50, blank=True, null=True)
    road_size = models.CharField(max_length=50, blank=True, null=True)
    built_up_area = models.CharField(max_length=100, blank=True, null=True)
    open_area = models.CharField(max_length=100, blank=True, null=True)
    rental_income = models.CharField(max_length=100, blank=True, null=True)
    dimensions = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.project_name




from django.db import models

class LandProperty(models.Model):
    LAND_TYPE_CHOICES = [
        ('Agricultural', 'Agricultural'),
        ('Residential', 'Residential'),
        ('Commercial', 'Commercial'),
    ]

    type_of_land = models.CharField(max_length=50, choices=LAND_TYPE_CHOICES)
    extent = models.CharField(max_length=100)
    units = models.CharField(max_length=50)
    soil = models.CharField(max_length=100, blank=True, null=True)
    water_source = models.CharField(max_length=100, blank=True, null=True)
    road_size = models.CharField(max_length=100, blank=True, null=True)
    road_facing = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"{self.type_of_land} - {self.extent} {self.units}"



class DisputeLand(models.Model):
    land_type = models.CharField(max_length=100)
    extent = models.CharField(max_length=50)
    units = models.CharField(max_length=50)
    soil_type = models.CharField(max_length=50)
    zone = models.CharField(max_length=50)
    road_size = models.CharField(max_length=50)
    road_facing_size = models.CharField(max_length=50)
    dispute_description = models.TextField()
    intention = models.CharField(max_length=100)
    actual_price = models.CharField(max_length=50)
    sale_price = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return f"{self.land_type} - {self.zone}"
    




from django.db import models

class PropertyDemand(models.Model):
    land_type = models.CharField(max_length=100)
    extent = models.CharField(max_length=50)
    units = models.CharField(max_length=50)
    soil_type = models.CharField(max_length=50)
    zone = models.CharField(max_length=50)
    road_size = models.CharField(max_length=50)
    road_facing_size = models.CharField(max_length=50)
    development_type = models.CharField(max_length=100)
    expecting_advance = models.CharField(max_length=50)
    ratio = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.land_type} - {self.zone}"



from django.db import models

class FinalUpload(models.Model):
    location = models.CharField(max_length=255)
    location_url = models.URLField(blank=True, null=True)
    price = models.DecimalField(max_digits=12, decimal_places=2)

    main_photo = models.ImageField(upload_to='uploads/main_photos/', blank=True, null=True)
    videos = models.FileField(upload_to='uploads/videos/', blank=True, null=True)
    documents = models.FileField(upload_to='uploads/documents/', blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.location


class FinalUploadPhoto(models.Model):
    final_upload = models.ForeignKey(FinalUpload, on_delete=models.CASCADE, related_name='photos')
    image = models.ImageField(upload_to='uploads/photos/')

    def __str__(self):
        return f"Photo for {self.final_upload.location}"


from django.db import models

class CommonLand(models.Model):
    LAND_CHOICES = [
        ('Commercial', 'Commercial'),
        ('Industrial', 'Industrial'),
        ('Agricultural', 'Agricultural'),
        ('Residential', 'Residential'),
        ('Mixed Use', 'Mixed Use'),
    ]

    land_type = models.CharField(max_length=50, choices=LAND_CHOICES)
    extent = models.CharField(max_length=100)
    units = models.CharField(max_length=50)
    soil_type = models.CharField(max_length=100, blank=True, null=True)
    water_source = models.CharField(max_length=100, blank=True, null=True)
    road_size = models.CharField(max_length=100, blank=True, null=True)
    road_facing = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.land_type} - {self.extent}"




class FarmPlotProperty(models.Model):
    project_name = models.CharField(max_length=200)
    extent = models.CharField(max_length=100)
    units = models.CharField(max_length=50, choices=[
        ("sqft", "Sqft"),
        ("acres", "Acres"),
        ("guntas", "Guntas")
    ])
    facing = models.CharField(max_length=100)
    dimensions = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return self.project_name
    




    